from PIL import Image, ImageDraw, ImageFilter
from pathlib import Path
out=Path('/mnt/data/fruitful-microsite/assets')
sources={
 'welcome':Image.open('/mnt/data/the_moment_a_playful_produce_poster.png').convert('RGBA'),
 'design':Image.open('/mnt/data/fruitful_design_poster.png').convert('RGBA')
}
items=[('apple','welcome',(0,1060,345,1491)),('blueberry','welcome',(355,1170,740,1491)),('broccoli','welcome',(775,995,1055,1491)),('carrot','welcome',(0,0,280,415)),('lemon','welcome',(800,0,1055,375)),('banana','design',(0,0,275,380)),('avocado','design',(830,1120,1055,1491))]
for name,src,rect in items:
 im=sources[src].crop(rect)
 w,h=im.size
 # soft irregular oval/capsule crop, avoids harsh rectangular poster piece
 mask=Image.new('L',(w,h),0)
 d=ImageDraw.Draw(mask)
 d.ellipse((5,5,w-5,h-5),fill=255)
 mask=mask.filter(ImageFilter.GaussianBlur(9))
 im.putalpha(mask)
 im.thumbnail((500,500))
 im.save(out/(name+'.png'),optimize=True)
